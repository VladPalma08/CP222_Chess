import java.util.ArrayList;

import static java.lang.Thread.sleep;

public class Game {
    public Piece[][] board;
    public mainInterface test = new mainInterface();
    private whitePlayer whitePlayer;
    private blackPlayer blackPlayer;
    private ArrayList<Piece> whitePieces;
    private ArrayList<Piece> blackPieces;



    public Piece[][] getBoard() { //will return the location of current piece in the array
        return this.board;
    }

    public Piece getPiece(int position){
        Piece destinationPiece = null;
        if (destinationPiece.getPosition() == position) {
            return destinationPiece;
        }
        return destinationPiece;
    }

    public void setBoard(Piece[][] board) {
        this.board = board;
    }

    public ArrayList<Piece> getWhitePieces(){
        return whitePieces;
    }
    public ArrayList<Piece> getBlackPieces(){
        return blackPieces;
    }






    public Piece[][] fillBoard() { //filling the rows of the board
        /* Piece[][] represents the tiles of the board
        [0][0++] = {Rook, Knight, Bishop, ...}
        [1][0++] = {pawns ... }
        if a tile isn't filled, it has value of "null" */

            this.board[0][0] = new Rook(ColorOfPiece.BLACK, 0);
            this.board[0][1] = new Knight(ColorOfPiece.BLACK, 1);
            this.board[0][2] = new Bishop(ColorOfPiece.BLACK, 2);
            this.board[0][3] = new Queen(ColorOfPiece.BLACK, 3);
            this.board[0][4] = new King(ColorOfPiece.BLACK, 4);
            this.board[0][5] = new Bishop(ColorOfPiece.BLACK, 5);
            this.board[0][6] = new Knight(ColorOfPiece.BLACK, 6);
            this.board[0][7] = new Rook(ColorOfPiece.BLACK, 7);

            this.board[7][0] = new Rook(ColorOfPiece.WHITE, 56);
            this.board[7][1] = new Knight(ColorOfPiece.WHITE, 57);
            this.board[7][2] = new Bishop(ColorOfPiece.WHITE, 58);
            this.board[7][3] = new Queen(ColorOfPiece.WHITE, 59);
            this.board[7][4] = new King(ColorOfPiece.WHITE, 60);
            this.board[7][5] = new Bishop(ColorOfPiece.WHITE, 61);
            this.board[7][6] = new Knight(ColorOfPiece.WHITE, 62);
            this.board[7][7] = new Rook(ColorOfPiece.WHITE, 63);
            for (int i = 0; i < 8; i++) {
                this.board[1][i] = new Pawn(ColorOfPiece.BLACK, i + 8);
                this.board[6][i] = new Pawn(ColorOfPiece.WHITE, i + 48);
            }

        return this.board;
        //changing method to return board so we can use it and update it
    }
    public void refreshBoard() { //this is where pieces that were added to array are being called onto the actual ui
        int po1 = 0;
        for (Piece[] p : this.board) {
            for (Piece p1 : p) {
                if (p1 != null) {
                    test.boardupdate(p1, po1);
                }
                po1++;
            }
        }
        test.repaint();
    }



//    public ArrayList getWhitesMoves() {
//        ArrayList<Integer> whitemoves = new ArrayList<>();
//        for (Piece[] p : this.board) {
//            for (Piece p1 : p) {
//                if (p1 != null) {
//                    if (p1.getColor() == ColorOfPiece.WHITE) {
//                        ArrayList<Integer> toadd = p1.legalMove(board);
//                        for (int i : toadd) {
//                            if (!whitemoves.contains(i)) {
//                                whitemoves.add(i);
//                            }
//                        }
//                    }
//                }
//            }
//        }
//        return whitemoves;
//
//    }

//    public ArrayList<Integer> getBlacksMoves() {
//        ArrayList<Integer> blackmoves = new ArrayList<>();
//        for (Piece[] p : this.board) { //going through the arrays
//            for (Piece p1 : p) {
//                if (p1 != null) {
//                    if (p1.getColor() == ColorOfPiece.BLACK) {
//                        ArrayList<Integer> toAdd = p1.legalMove(board); //checking for all the legal moves
//                        for (int i : toAdd) {
//                            if (!blackmoves.contains(i)) {
//                                blackmoves.add(i);
//                            }
//                        }
//                    }
//                }
//            }
//        }
//        return blackmoves;
//
//    }


    //IN ORDER TO GET PIECES THAT ARE CURRENTLY ON THE BOARD:
    public ArrayList<Piece> getCurrentPieces(Piece[][] board, ColorOfPiece color){
        ArrayList<Piece> currentPieces = new ArrayList<>();
        for (Piece[] p : board){
            for (Piece p1: p){ //need nested for loop bc it needs to iterate through array then indivd. objects in the array
                if (p1 != null){
                    Piece currentPiece = p1;
                    if (currentPiece.getColor() == color){
                        currentPieces.add(currentPiece);
                    }
                }
            }
        }
        return currentPieces;
    }


}



