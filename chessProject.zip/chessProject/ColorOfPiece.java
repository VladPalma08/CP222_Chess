public enum ColorOfPiece {
    WHITE,
    BLACK
}
