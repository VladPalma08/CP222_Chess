import java.awt.*;
import java.util.ArrayList;

abstract class Piece {
        public ColorOfPiece color;
        public  int position;

        public Piece(ColorOfPiece color, int position) {
            this.color = color;
            this.position = position;
        }
        public void setPosition(int newPos){
            this.position=newPos;
        } //newPos = new position

        public ColorOfPiece getColor() {
            return color;
        }
        public abstract ArrayList<Move> legalMove(Game board);
        public abstract Image getImage();
        public int getPosition(){
            return position;
        }

        public boolean isKing(){
            return false;
        } //every piece except king will return false for this

    }
