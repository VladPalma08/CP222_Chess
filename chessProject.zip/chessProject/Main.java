public class Main {
    public static void main(String[] args) {
        Game game = new Game();
        game.fillBoard();
        game.refreshBoard();


        //        try{sleep(1000);
//        } catch (Exception e) {}
//        game.movepeice(0,22);
//        try{sleep(1000);
//        } catch (Exception e) {}
//        game.movepeice(2,21);
//        try{sleep(1000);
//        } catch (Exception e) {}
//        game.movepeice(22,40);

    }
}
