public interface player {

}
