public class human {
}
