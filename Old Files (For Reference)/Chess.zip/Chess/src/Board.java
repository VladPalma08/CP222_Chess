import javax.swing.*;
import java.awt.*;

public class Board extends JFrame {

    private JButton button1;
    private JButton button2;
    private JPanel placeholder;
    public Board() {

//        Board.set
        placeholder.setSize(900, 900);

//        placeholder.setVisible(false);
//        this.setBounds(placeholder.getBounds());
//        this.setBackground(placeholder.getBackground());
//        this.setBorder(placeholder.getBorder());
    }

    public void drawBoard() {


    }

//    protected void paintChildren(Graphics g) {
//        Graphics2D g2 = (Graphics2D) g;
//        g2.setColor(Color.white);
//
//        int filledSquare = placeholder.getWidth()/8;
//
//        for (int i = 0; i < 4; i++) {
//            g2.fillRect(2 * i * filledSquare, 0, filledSquare, filledSquare);
//        }
//    }




}


