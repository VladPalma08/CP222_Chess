public class regularMove extends Move{
    public regularMove(Game board, Piece pieceToMove, int movePosition) {
        super(board, pieceToMove, movePosition);
    }
}
