public enum moveStatus {
    DONE,
    ILLEGALMOVE,
    PUTS_IN_CHECK

}
