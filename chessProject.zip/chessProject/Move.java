import java.util.ArrayList;

public abstract class Move {
    Game board;
    Piece pieceToMove;
    int movePosition;

    Move(Game board, Piece pieceToMove, int movePosition){
        this.board = board;
        this.pieceToMove = pieceToMove;
        this.movePosition = movePosition;
    }

    public int getAttacks(){
        return movePosition;
    }

}
