
import java.util.ArrayList;


public abstract class Player {
    private Game board;
    private King king;
    private ArrayList<Move> moves, enemyMoves, canTake; //or whatever will be used to store the possible moves
    private Piece piece;
    private boolean check;

    //TODO: Create Moves class that will store piece's possible moves

    public Player(Game board, ArrayList<Move> moves, ArrayList<Move> enemyMoves){
        this.board = board;
        this.moves = moves;


        this.king = getKing();
        this.check = isInCheck();


    }

    //override in black and white class to get all pieces of both sides
    public abstract ArrayList<Piece> getPieces(); // to get current pieces on board for black and white side
    public abstract ArrayList<Piece> getOpponentPieces();
    public abstract ColorOfPiece getColor();

    public King getKing(){
        for(Piece piece: getPieces()){
            if (piece.isKing()) { //have boolean in piece abstract class that is used for determining king
                return king;
            }
        }
        return king;
        //since we are creating every piece as their own object, we can keep track of the king's position to check for things like check,checkmate, etc
    }


    //this method will be used to determine check, checkmate, stalemate, etc
    public ArrayList<Move> allPossibleAttacks(int piecePosition, ArrayList<Move> enemyMoves){ /*enemyMoves will correspond to current side's enemy (so if ur working
                                                                                                 on Black, then enemyMove should be all possible moves of White)*/
        canTake = new ArrayList<>();
        for (Move moves: enemyMoves ){ //(for every move in arraylist 'enemyMoves')
            if(piecePosition == moves.getAttacks()){ //TODO: in Moves class, create method that will get possible attacks of all pieces
                //if the piecePosition is equal to any position that enemy can move to then add it to canTake
                canTake.add(moves);
            }
        }
        return canTake;
    }

    public boolean isInCheck(){
        if(allPossibleAttacks(this.king.position, enemyMoves).isEmpty()){
            return false;
        }
        else {
            return true;
        }
    }

    public boolean canEscape(){
        boolean escape = false;
        //TODO: put in method tht allows u to see if king can escape a check
        for(Move moves: this.moves){
            if (this.king.legalMove(board) != allPossibleAttacks(this.king.position, enemyMoves)){
                //if the king's list of move does not equal list of all possible enemy moves
                escape = true;
            }
            else{
                escape = false;

            }
        }

        return escape;
    }

    public boolean isInCheckMate(){
            return isInCheck() && canEscape() == false;

    }




}
