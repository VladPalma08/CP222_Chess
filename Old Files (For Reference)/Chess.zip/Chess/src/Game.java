import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

import static java.lang.Thread.sleep;

public class Game {
    public Piece[][] board = new Piece[8][8];

    public Piece[][] getBoard() {
        return board;
    }

    public void setBoard(Piece[][] board) {
        this.board = board;
    }

    public mainInterface test = new mainInterface();


    public static void main(String[] args) {
        Game game = new Game();
        game.fillBoard();
        game.refreshboard();
        try{sleep(1000);
        } catch (Exception e) {}
        game.movepeice(0,22);
        try{sleep(1000);
        } catch (Exception e) {}
        game.movepeice(2,21);
        try{sleep(1000);
        } catch (Exception e) {}
        game.movepeice(22,40);

    }


    public void movepeice(int pos1, int pos2) {
        Piece tomove = board[pos1 / 8][pos1 % 8];
        board[pos1 / 8][pos1 % 8] = null;
        board[pos2 / 8][pos2 % 8]=tomove;
        board[pos2 / 8][pos2 % 8].setpostion(pos2);
        test.boardRemove(pos1);
        refreshboard();
    }

    public void refreshboard() {
        int po1 = 0;
        for (Piece[] p : this.board) {
            for (Piece p1 : p) {
                if (p1 != null) {
                    test.boardupdate(p1, po1);
                }
                po1++;
            }
        }
        test.repaint();
    }

    public void fillBoard() {
        this.board[0][0] = new Rook(ColorOfPiece.BLACK, 0);
        this.board[0][1] = new Knight(ColorOfPiece.BLACK, 1);
        this.board[0][2] = new Bishop(ColorOfPiece.BLACK, 2);
        this.board[0][3] = new Queen(ColorOfPiece.BLACK, 3);
        this.board[0][4] = new King(ColorOfPiece.BLACK, 4);
        this.board[0][5] = new Bishop(ColorOfPiece.BLACK, 5);
        this.board[0][6] = new Knight(ColorOfPiece.BLACK, 6);
        this.board[0][7] = new Rook(ColorOfPiece.BLACK, 7);

        this.board[7][0] = new Rook(ColorOfPiece.WHITE, 56);
        this.board[7][1] = new Knight(ColorOfPiece.WHITE, 57);
        this.board[7][2] = new Bishop(ColorOfPiece.WHITE, 58);
        this.board[7][3] = new Queen(ColorOfPiece.WHITE, 59);
        this.board[7][4] = new King(ColorOfPiece.WHITE, 60);
        this.board[7][5] = new Bishop(ColorOfPiece.WHITE, 61);
        this.board[7][6] = new Knight(ColorOfPiece.WHITE, 62);
        this.board[7][7] = new Rook(ColorOfPiece.WHITE, 63);
        for (int i = 0; i < 8; i++) {
            this.board[1][i] = new Pawn(ColorOfPiece.BLACK, i + 8);
            this.board[6][i] = new Pawn(ColorOfPiece.WHITE, i + 48);
        }

    }


    public ArrayList getwhitesmoves() {
        ArrayList<Integer> whitemoves = new ArrayList<Integer>();
        for (Piece[] p : this.board) {
            for (Piece p1 : p) {
                if (p1 != null) {
                    if (p1.getColor() == ColorOfPiece.WHITE) {
                        ArrayList<Integer> toadd = p1.legalMove(board);
                        for (int i : toadd) {
                            if (!whitemoves.contains(i)) {
                                whitemoves.add(i);
                            }
                        }
                    }
                }
            }
        }
        return whitemoves;

    }

    public ArrayList getblackmoves() {
        ArrayList<Integer> whitemoves = new ArrayList<Integer>();
        for (Piece[] p : this.board) {
            for (Piece p1 : p) {
                if (p1 != null) {
                    if (p1.getColor() == ColorOfPiece.BLACK) {
                        ArrayList<Integer> toadd = p1.legalMove(board);
                        for (int i : toadd) {
                            if (!whitemoves.contains(i)) {
                                whitemoves.add(i);
                            }
                        }
                    }
                }
            }
        }
        return whitemoves;

    }
}



